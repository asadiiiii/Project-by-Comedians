function checkPasswordStrength() {
    const password = document.getElementById('passwordInput').value;
    const strengthText = document.getElementById('strengthText');
    const strengthResult = document.getElementById('strengthResult');

    let strength = 0;

    // 长度检测
    if (password.length >= 8) {
        strength += 1;
    }

    // 字符多样性检测
    if (/[A-Z]/.test(password)) {
        strength += 1;
    }
    if (/[a-z]/.test(password)) {
        strength += 1;
    }
    if (/[0-9]/.test(password)) {
        strength += 1;
    }
    if (/[^A-Za-z0-9]/.test(password)) {
        strength += 1;
    }

    // 根据强度设置文本和颜色
    switch (strength) {
        case 0:
        case 1:
        case 2:
            strengthText.textContent = '弱';
            strengthResult.className = 'weak';
            break;
        case 3:
        case 4:
            strengthText.textContent = '中等';
            strengthResult.className = 'medium';
            break;
        case 5:
            strengthText.textContent = '强';
            strengthResult.className = 'strong';
            break;
    }
}