function calculateDuration() {
    var startTime = document.getElementById('startTime').value;
    var endTime = document.getElementById('endTime').value;
    var start = new Date(startTime);
    var end = new Date(endTime);
    var duration = end - start; // 毫秒
    var days = Math.floor(duration / (1000 * 60 * 60 * 24));
    duration -= days * (1000 * 60 * 60 * 24);
    var hours = Math.floor(duration / (1000 * 60 * 60));
    duration -= hours * (1000 * 60 * 60);
    var minutes = Math.floor(duration / (1000 * 60));
    document.getElementById('result').innerText = '时间长度: ' + days + ' 天 ' + hours + ' 小时 ' + minutes + ' 分钟';
}