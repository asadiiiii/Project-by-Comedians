document.getElementById('dateCalculatorForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const startDate = new Date(document.getElementById('startDate').value);
    const endDate = new Date(document.getElementById('endDate').value);

    const totalDays = calculateTotalDays(startDate, endDate);
    const holidays = calculateHolidays(startDate, endDate);
    const workdays = calculateWorkdays(startDate, endDate, holidays);
    const weekends = calculateWeekends(startDate, endDate, holidays);

    updateResults(workdays, weekends, holidays.length, totalDays);
});

function calculateTotalDays(startDate, endDate) {
    return (endDate - startDate) / (1000 * 60 * 60 * 24) + 1;
}

function calculateHolidays(startDate, endDate) {
    let holidays = [];
    let currentDate = new Date(startDate);
    const holidaysRanges = [
        { start: '12-30', end: '01-01' },
        { start: '02-10', end: '02-17' },
        { start: '04-04', end: '04-06' },
        { start: '05-01', end: '05-05' },
        { start: '06-08', end: '06-10' },
        { start: '09-15', end: '09-17' },
        { start: '10-01', end: '10-07' }
    ];

    while (currentDate <= endDate) {
        const year = currentDate.getFullYear();
        for (let holidayRange of holidaysRanges) {
            const holidayStart = new Date(`${year}-${holidayRange.start}`);
            const holidayEnd = new Date(`${year}-${holidayRange.end}`);
            if (currentDate >= holidayStart && currentDate <= holidayEnd) {
                holidays.push(new Date(currentDate));
            }
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }

    return holidays;
}

function calculateWorkdays(startDate, endDate, holidays) {
    let workdaysCount = 0;
    let currentDate = new Date(startDate);

    while (currentDate <= endDate) {
        if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6 && !isDateInHolidays(currentDate, holidays)) {
            workdaysCount++;
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }

    return workdaysCount;
}

function calculateWeekends(startDate, endDate, holidays) {
    let weekendsCount = 0;
    let currentDate = new Date(startDate);

    while (currentDate <= endDate) {
        if ((currentDate.getDay() === 0 || currentDate.getDay() === 6) && !isDateInHolidays(currentDate, holidays)) {
            weekendsCount++;
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }

    return weekendsCount;
}

function isDateInHolidays(date, holidays) {
    const dateStr = date.toISOString().split('T')[0];
    for (let holiday of holidays) {
        const holidayDateStr = holiday.toISOString().split('T')[0];
        if (dateStr === holidayDateStr) {
            return true;
        }
    }
    return false;
}

function updateResults(workdays, weekends, holidays, totalDays) {
    document.getElementById('workdays').textContent = workdays;
    document.getElementById('weekends').textContent = weekends;
    document.getElementById('holidays').textContent = holidays;
    document.getElementById('totalDays').textContent = totalDays;
}