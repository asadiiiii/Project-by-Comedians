function calculateFactorial(num) {
    let result = 1;
    for (let i = 2; i <= num; i++) {
        result *= i;
    }
    return result;
}

function calculate() {
    const n = parseInt(document.getElementById('n').value);
    const r = parseInt(document.getElementById('r').value);
    const nFactorial = calculateFactorial(n);
    const rFactorial = calculateFactorial(r);
    const nMinusRFactorial = calculateFactorial(n - r);

    const permutation = (nFactorial / nMinusRFactorial).toFixed(0);
    const combination = (nFactorial / (rFactorial * nMinusRFactorial)).toFixed(0);

    document.getElementById('result').innerText = `排列 P(${n}, ${r}): ${permutation}, 组合 C(${n}, ${r}): ${combination}`;
}

function calculateDerangement() {
    const n = parseInt(document.getElementById('n').value);
    const derangement = derangementCalculation(n);
    document.getElementById('derangementResult').innerText = `错排 D(${n}): ${derangement}`;
}

function derangementCalculation(n) {
    if (n === 0) return 1;
    if (n === 1) return 0;
    let derangement = [1, 0]; // 初始化数组，存储错排的结果
    for (let i = 2; i <= n; i++) {
        derangement[i] = (i - 1) * (derangement[i - 1] + derangement[i - 2]);
    }
    return derangement[n];
}