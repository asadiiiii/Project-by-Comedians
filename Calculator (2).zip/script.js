document.addEventListener('DOMContentLoaded', function() {
    const textLines = [
        "This is a miscellaneous calculator.",
        "It will be interesting for you",
        "to use it in daily life.",
        "by the Comedians."
    ];

    const textContainer = document.getElementById('text-container');
    const enterButton = document.getElementById('enter-button');

    let currentLine = 0;
    const delay = 1000; // 每行文本之间的延迟时间

    function revealNextLine() {
        if (currentLine < textLines.length) {
            const line = document.createElement('p');
            line.textContent = textLines[currentLine];
            textContainer.appendChild(line);
            currentLine++;
            setTimeout(revealNextLine, delay + (currentLine * 500)); // 每行文本显示后等待500ms
        } else {
            enterButton.style.display = 'block';
            enterButton.style.animation = 'fadeInButton 2s ease forwards';
        }
    }

    revealNextLine();

    enterButton.addEventListener('click', function() {
        window.location.href = 'hom.html';
    });
});