let display = document.getElementById('display');
let currentInput = '';
let previousInput = '';
let operation = null;

// 输入数字或小数点
function input(value) {
  currentInput += value;
  display.value = currentInput;
}

// 计算结果
function calculate(op) {
  if (operation && previousInput !== '' && currentInput !== '') {
    const prevInput = parseFloat(previousInput);
    const currInput = parseFloat(currentInput);
    let result = 0;
    switch (operation) {
      case '+':
        result = prevInput + currInput;
        break;
      case '-':
        result = prevInput - currInput;
        break;
      case '*':
        result = prevInput * currInput;
        break;
      case '/':
        if (currInput === 0) {
          alert('除数不能为0');
          currentInput = ''; // 清除错误输入
          return;
        } else {
          result = prevInput / currInput;
        }
        break;
    }
    previousInput = result.toString();
    currentInput = '';
    if (op === '=') {
      display.value = result;
      previousInput = result.toString();
      currentInput = '';
      operation = null;
    } else {
      operation = op;
      previousInput = result.toString();
      currentInput = '';
    }
  } else if (op === '=' && currentInput !== '') {
    display.value = parseFloat(previousInput) + op + currentInput;
    const result = eval(display.value);
    display.value = result;
    previousInput = result.toString();
    currentInput = '';
    operation = null;
  } else if (currentInput !== '' && op !== '=') {
    operation = op;
    previousInput = currentInput;
    currentInput = '';
  }
}

// 清空显示和变量
function clearDisplay() {
  previousInput = '';
  currentInput = '';
  operation = null;
  display.value = '';
}