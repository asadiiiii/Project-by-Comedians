document.getElementById('bacForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const weight = parseFloat(document.getElementById('weight').value);
    const gender = document.getElementById('gender').value;
    const beerAmount = parseFloat(document.getElementById('beerAmount').value) * parseFloat(document.getElementById('beerAlcohol').value) / 100;
    const wineAmount = parseFloat(document.getElementById('wineAmount').value) * parseFloat(document.getElementById('wineAlcohol').value) / 100;
    const liquorAmount = parseFloat(document.getElementById('liquorAmount').value) * parseFloat(document.getElementById('liquorAlcohol').value) / 100;
    const spiritAmount = parseFloat(document.getElementById('spiritAmount').value) * parseFloat(document.getElementById('spiritAlcohol').value) / 100;
    const totalAlcohol = beerAmount + wineAmount + liquorAmount + spiritAmount;

    const constants = {
        male: { weightFactor: 0.68, distribution: 0.73 },
        female: { weightFactor: 0.55, distribution: 0.68 }
    };

    const genderSpecific = constants[gender];
    const rateOfElimination = 0.015;
    const bac = (totalAlcohol / (weight * genderSpecific.weightFactor)) * genderSpecific.distribution;
    const soberTime = (bac / rateOfElimination) * 60; // Convert to minutes

    document.getElementById('bacValue').textContent = bac.toFixed(2);
    document.getElementById('soberTime').textContent = soberTime / 60; // Convert back to hours
});

function calculateBAC(weight, gender, alcoholAmount, time) {
    const constants = {
        male: { weightFactor: 0.68, distribution: 0.73 },
        female: { weightFactor: 0.55, distribution: 0.68 }
    };

    const genderSpecific = constants[gender];
    const rateOfAbsorption = 0.015;
    const rateOfElimination = 0.015;
    const totalAlcoholInBody = alcoholAmount * 0.8;

    const bac = (totalAlcoholInBody / (weight * genderSpecific.weightFactor)) * genderSpecific.distribution;
    const timeFactor = Math.pow(bac / rateOfAbsorption, rateOfElimination / rateOfAbsorption) * Math.exp(-rateOfElimination / rateOfAbsorption * time);

    return bac * timeFactor;
}