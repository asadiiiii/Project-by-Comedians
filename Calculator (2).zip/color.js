document.addEventListener('DOMContentLoaded', function() {
    const colorItems = document.querySelectorAll('.color-item');
    const color1Display = document.getElementById('color1Display');
    const color2Display = document.getElementById('color2Display');
    const mixColorsButton = document.getElementById('mixColors');
    const clearColorsButton = document.getElementById('clearColors');
    const resultDiv = document.getElementById('result');

    let selectedColor1 = null;
    let selectedColor2 = null;

    colorItems.forEach(item => {
        item.addEventListener('click', function() {
            const color = item.getAttribute('data-color');
            if (selectedColor1 === null) {
                selectedColor1 = color;
                item.style.borderColor = 'white';
                color1Display.style.backgroundColor = item.style.backgroundColor;
                color1Display.textContent = '';
            } else if (selectedColor2 === null && color !== selectedColor1) {
                selectedColor2 = color;
                item.style.borderColor = 'white';
                color2Display.style.backgroundColor = item.style.backgroundColor;
                color2Display.textContent = '';
            } else {
                item.style.borderColor = 'black';
                if (color === selectedColor1) {
                    selectedColor1 = null;
                    color1Display.style.backgroundColor = '#ddd';
                    color1Display.textContent = '选择颜色1';
                } else {
                    selectedColor2 = null;
                    color2Display.style.backgroundColor = '#ddd';
                    color2Display.textContent = '选择颜色2';
                }
            }
        });
    });

    mixColorsButton.addEventListener('click', function() {
        if (selectedColor1 && selectedColor2) {
            const mixedColor = mixColors(selectedColor1, selectedColor2);
            resultDiv.style.backgroundColor = mixedColor;
            resultDiv.textContent = `混合颜色: ${mixedColor}`;
        } else {
            alert('请选择两种颜色');
        }
    });

    clearColorsButton.addEventListener('click', function() {
        selectedColor1 = null;
        selectedColor2 = null;
        colorItems.forEach(item => {
            item.style.borderColor = 'black';
        });
        color1Display.style.backgroundColor = '#ddd';
        color1Display.textContent = '选择颜色1';
        color2Display.style.backgroundColor = '#ddd';
        color2Display.textContent = '选择颜色2';
        resultDiv.textContent = '';
    });

    function mixColors(color1, color2) {
        const colorMap = {
            red: [255, 0, 0],
            yellow: [255, 255, 0],
            blue: [0, 0, 255],
            green: [0, 128, 0],
            orange: [255, 165, 0],
            purple: [128, 0, 128],
            white: [255, 255, 255],
            black: [0, 0, 0],
            gray: [128, 128, 128]
        };

        const rgb1 = colorMap[color1];
        const rgb2 = colorMap[color2];
        const mixedRgb = rgb1.map((channel, index) => Math.round((channel + rgb2[index]) / 2));
        return `rgb(${mixedRgb.join(', ')})`;
    }
});