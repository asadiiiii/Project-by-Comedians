let currentInput = null;

// 初始化输入框的点击事件
document.querySelectorAll('.ratio-input').forEach(input => {
    input.addEventListener('click', function() {
        currentInput = this;
    });
});

document.getElementById('ratioForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const ratio1 = parseFloat(document.getElementById('ratio1').value);
    const ratio2 = parseFloat(document.getElementById('ratio2').value);
    const scaleFactor = document.getElementById('scaleFactor').value ? parseFloat(document.getElementById('scaleFactor').value) : 1;

    const simplified = simplifyRatio(ratio1, ratio2);
    const scaled = scaleRatio(simplified.ratio1, simplified.ratio2, scaleFactor);

    document.getElementById('simplifiedRatio').textContent = `${simplified.ratio1} : ${simplified.ratio2}`;
    document.getElementById('scaledRatio').textContent = `${scaled.ratio1} : ${scaled.ratio2}`;
});

function simplifyRatio(a, b) {
    const gcd = greatestCommonDivisor(a, b);
    return { ratio1: a / gcd, ratio2: b / gcd };
}

function scaleRatio(ratio1, ratio2, scaleFactor) {
    return { ratio1: ratio1 * scaleFactor, ratio2: ratio2 * scaleFactor };
}

function greatestCommonDivisor(a, b) {
    while (b !== 0) {
        const temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

function appendNumber(number) {
    if (currentInput) {
        const currentValue = currentInput.value;
        currentInput.value = currentValue + number;
    }
}

function clearActiveInput() {
    if (currentInput) {
        currentInput.value = '';
    }
}

function deleteLastChar() {
    if (currentInput) {
        const currentValue = currentInput.value;
        currentInput.value = currentValue.substring(0, currentValue.length - 1);
    }
}