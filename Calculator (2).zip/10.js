document.addEventListener('DOMContentLoaded', function () {
    let remainingDraws = 50;
    const drawOneButton = document.getElementById('drawOne');
    const drawTenButton = document.getElementById('drawTen');
    const resultsContainer = document.getElementById('results');
    const remainingDrawsDisplay = document.getElementById('remaining');
  
    let cardCounts = {
      ssr: 0,
      sr: 0,
      s: 0,
      a: 0
    };
  
    function drawCard(cardType) {
      const cardElement = document.createElement('div');
      cardElement.className = `card ${cardType}`;
      cardElement.textContent = cardType.toUpperCase();
      resultsContainer.appendChild(cardElement);
  
      cardCounts[cardType]++;
      updateRemaining();
    }
  
    function updateRemaining() {
      remainingDraws--;
      remainingDrawsDisplay.textContent = remainingDraws;
  
      if (remainingDraws === 0) {
        drawOneButton.disabled = true;
        drawTenButton.disabled = true;
        showStatistics();
      }
    }
  
    function showStatistics() {
      const evaluationClass = evaluate(cardCounts);
      displayStatistics(cardCounts, evaluationClass);
    }
  
    function displayStatistics(stats, evaluationClass) {
      const statsElement = document.createElement('div');
      statsElement.className = 'stats';
      statsElement.innerHTML = `
        <div class="label">SSR:</div><div class="value">${stats.ssr}</div>
        <div class="label">SR:</div><div class="value">${stats.sr}</div>
        <div class="label">S:</div><div class="value">${stats.s}</div>
        <div class="label">A:</div><div class="value">${stats.a}</div>
        <div class="label">欧气评价:</div><div class="value ${evaluationClass}">${getEvaluationText(evaluationClass)}</div>
      `;
      resultsContainer.appendChild(statsElement);
    }
  
    function evaluate(stats) {
      let evaluation = '';
      if (stats.ssr > 2) {
        evaluation = '欧皇';
        return 'evaluation-emperor'; // 返回CSS类名
      } else if (stats.ssr > 0) {
        evaluation = '欧皇候选人';
        return 'evaluation-candidate';
      } else if (stats.sr > 10) {
        evaluation = '小欧皇';
        return 'evaluation-small';
      } else {
        evaluation = '非酋';
        return 'evaluation-normal';
      }
    }
  
    function getEvaluationText(evaluationClass) {
      switch (evaluationClass) {
        case 'evaluation-emperor':
          return '欧皇';
        case 'evaluation-candidate':
          return '欧皇候选人';
        case 'evaluation-small':
          return '小欧皇';
        case 'evaluation-normal':
          return '非酋';
        default:
          return '未知评价';
      }
    }
  
    drawOneButton.addEventListener('click', function () {
      if (remainingDraws > 0) {
        const cardType = getRandomCardType();
        drawCard(cardType);
      }
    });
  
    drawTenButton.addEventListener('click', function () {
      if (remainingDraws > 0) {
        for (let i = 0; i < 10 && remainingDraws > 0; i++) {
          const cardType = getRandomCardType();
          drawCard(cardType);
        }
      }
    });
  
    function getRandomCardType() {
      const probabilities = {
        ssr: 2, sr: 8, s: 20, a: 70
      };
      let roll = Math.floor(Math.random() * 100) + 1;
      let cardType = '';
  
      if (roll <= probabilities.ssr) {
        cardType = 'ssr';
      } else if (roll <= probabilities.ssr + probabilities.sr) {
        cardType = 'sr';
      } else if (roll <= probabilities.ssr + probabilities.sr + probabilities.s) {
        cardType = 's';
      } else {
        cardType = 'a';
      }
  
      return cardType;
    }
  });