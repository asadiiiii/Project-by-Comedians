let startTime;
let endTime;
let questionCount = 0;
const questionArea = document.getElementById('questionArea');
const startButton = document.getElementById('startButton');
const question = document.getElementById('question');
const greaterButton = document.getElementById('greaterButton');
const lessButton = document.getElementById('lessButton');
const feedback = document.getElementById('feedback');

startButton.addEventListener('click', startTest);

function startTest() {
    questionArea.style.display = 'block';
    startButton.style.display = 'none';
    resetTest(); 
    startTime = new Date(); 
    askQuestion();
}

function resetTest() {
    questionCount = 0; 
    feedback.textContent = ''; 
    question.textContent = ''; 
    greaterButton.onclick = null;
    lessButton.onclick = null;
    const retryButton = document.getElementById('retryButton');
    if (retryButton) {
        retryButton.remove(); 
    }
}

function askQuestion() {
    const num1 = Math.floor(Math.random() * 20) + 1;
    let num2;
    do {
        num2 = Math.floor(Math.random() * 20) + 1;
    } while (num2 === num1); 

    question.textContent = `${num1} 和 ${num2} 比较，是大于还是小于？`;

    greaterButton.onclick = () => checkAnswer(num1, num2, 'greater');
    lessButton.onclick = () => checkAnswer(num1, num2, 'less');
}

function checkAnswer(num1, num2, userAnswer) {
    if ((userAnswer === 'greater' && num1 > num2) || (userAnswer === 'less' && num1 < num2)) {
        feedback.textContent = '正确！';
        feedback.style.color = 'green';
        questionCount++;
        if (questionCount < 10) {
            askQuestion();
        } else {
            endTime = new Date(); 
            const totalTime = (endTime - startTime) / 1000;
            showResults(totalTime);
        }
    } else {
        feedback.textContent = '错误，请重试！';
        feedback.style.color = 'red';
        greaterButton.onclick = null;
        lessButton.onclick = null;
        setTimeout(() => askQuestion(), 2000); 
    }
}

function showResults(totalTime) {
    const reactionSpeed = calculateReactionSpeed(totalTime);
    const color = reactionSpeedColor(reactionSpeed);
    const wittyComment = getWittyComment(reactionSpeed);
    questionArea.innerHTML = `
        <h2>测试完成！</h2>
        <p>你的总用时为 <span style="color: ${color}">${totalTime.toFixed(2)} 秒</span>。</p>
        <p>你的大脑反应速度评级为：<span style="color: ${color}">${reactionSpeed}</span></p>
        <p><span style="color: ${color}">${wittyComment}</span></p>
        <button id="retryButton">重新测试</button>
    `;
    const retryButton = document.getElementById('retryButton');
    retryButton.addEventListener('click', startTest);
}

function calculateReactionSpeed(time) {
    if (time < 8) return '非常快';
    if (time < 12) return '快';
    if (time < 16) return '中等';
    return '慢';
}

function reactionSpeedColor(speed) {
    if (speed === '非常快') return 'blue';
    if (speed === '快') return 'green';
    if (speed === '中等') return 'orange';
    return 'red';
}

function getWittyComment(speed) {
    if (speed === '非常快') return "您已经超过了xx口算中99%的炸鱼大学生！";
    if (speed === '快') return "您已经超过了xx口算中50%的炸鱼大学生！";
    if (speed === '中等') return "小朋友，再接再厉！";
    return "仁济！";
}